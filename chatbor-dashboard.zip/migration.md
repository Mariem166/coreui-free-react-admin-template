# Migration from version 3

https://coreui.io/react/docs/4.0/migration/v4/

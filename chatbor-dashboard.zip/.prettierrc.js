module.exports = {
  semi: true,
  trailingComma: "none",
  singleQuote: true,
    printWidth: 80,
  
};
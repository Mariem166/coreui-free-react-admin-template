import React from "react";
const Allquestions =(props) => {
    return <div> Hello I am AllQuestions</div>
};
export default Allquestions
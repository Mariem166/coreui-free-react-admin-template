import React from "react";
const Deletequestion=(props) => {
    return <div> Hello I am Deletequestion</div>
};
export default Deletequestion ;
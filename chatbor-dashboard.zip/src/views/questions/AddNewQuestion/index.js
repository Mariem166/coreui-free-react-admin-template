import React from "react";
const AddNewQuestion =(props) => {
    return <div>AddNewQuestions</div>
};
export default AddNewQuestion;